document.addEventListener("DOMContentLoaded", function() {
    const gameCanvas = document.getElementById('gameCanvas');
    const ctx = gameCanvas.getContext('2d');
    const gameFile = document.getElementById('gameFile');
    const uploadButton = document.getElementById('uploadButton');
    const gameContent = document.getElementById('gameContent');

    uploadButton.addEventListener('click', () => {
        gameFile.click();
    });

    gameFile.addEventListener('change', (event) => {
        const file = event.target.files[0];
        if (file) {
            processGameFile(file);
        }
    });

    function processGameFile(file) {
        const reader = new FileReader();
        reader.onload = function(event) {
            const arrayBuffer = event.target.result;
            unpackJar(arrayBuffer);
        };
        reader.readAsArrayBuffer(file);
    }

    function unpackJar(arrayBuffer) {
        // Use a library like jszip to unpack the JAR file
        // For simplicity, this example just lists the file name
        // Replace this with actual JAR processing logic
        gameContent.innerHTML = `<p>Uploaded file: ${gameFile.files[0].name}</p>`;
        console.log("jszip version:" + jszip.version)
        jszip.loadAsync(arrayBuffer)
        .then(function (zip) {
            console.log(zip.files);
             gameContent.innerHTML = '<h3>File List:</h3><ul>';
                for (const filename in zip.files) {
                    gameContent.innerHTML += `<li>${filename}</li>`;
                }
                gameContent.innerHTML += '</ul>';
        });
    }

    // Mock J2ME methods (very basic)
    const Font = {
        getFont: (face, style, size) => {
            return { face, style, size };
        },
        FACE_SYSTEM: 0,
        STYLE_BOLD: 1,
        SIZE_MEDIUM: 0
    };

    const Graphics = {
        setColor: (r, g, b) => {
            ctx.fillStyle = `rgb(${r}, ${g}, ${b})`;
        },
        fillRect: (x, y, width, height) => {
            ctx.fillRect(x, y, width, height);
        },
        drawString: (text, x, y, anchor) => {
            ctx.fillText(text, x, y);
        },
        setFont: (font) => {
            ctx.font = `${font.style ? 'bold' : ''} ${font.size}px ${font.face}`;
        },
        translate: (x, y) => {
            ctx.translate(x, y);
        },
        drawImage: (img, x, y, anchor) => {
             ctx.drawImage(img, x, y);
        },
        // Anchor constants
        TOP: 1,
        LEFT: 2,
        BOTTOM: 4,
        RIGHT: 8,
        HCENTER: 16,
        VCENTER: 32,
        // Add more methods as needed
    };

    const Image = {
        createImage: (width, height) => {
            const canvas = document.createElement('canvas');
            canvas.width = width;
            canvas.height = height;
            return canvas;
        },
        // Add more methods as needed
    };

    // Mock GameCanvas
    const GameCanvas = {
        getGraphics: () => {
            return Graphics;
        },
        getWidth: () => {
            return gameCanvas.width;
        },
        getHeight: () => {
            return gameCanvas.height;
        },
        // Add more methods as needed
    };

    // Mock Display
    const Display = {
        getDisplay: () => {
            return {
                getCurrent: () => {
                    return {
                        getWidth: () => {
                            return gameCanvas.width;
                        },
                        getHeight: () => {
                            return gameCanvas.height;
                        }
                    };
                }
            };
        }
        // Add more methods as needed
    };

    // Load and initialize the converted game
    const script = document.createElement('script');
    script.src = 'assets/game_files/jogoConvertido.js';
    document.body.appendChild(script);

    script.onload = () => {
        // Initialize the game after loading, passing in mocked J2ME objects
        if (typeof inicializarJogo === 'function') {
            inicializarJogo(GameCanvas, Font, Graphics, Image, Display);
        } else {
            console.error('inicializarJogo function not found in jogoConvertido.js');
        }

        // Start the game loop (if applicable)
        if (typeof startGameLoop === 'function') {
            startGameLoop();
        }
    };
});